# colorchangerPDF
Many existing tools on the website or Google extensions either don’t work or require you to upload your PDFs to a server, something I don’t trust with personal files. So, I created colorchangerPDF, a Python tool that lets you convert any PDF to a dark mode version, safely on your own machine.

Requirements Python 3.9+ PyMuPDF Pillow NumPy tqdm